import java.sql.*;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        DBConnection.connect();
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\n1. Add Expense");
            System.out.println("2. View Expenses");
            System.out.println("3. Monthly Summary");
            System.out.println("4. Exit");
            System.out.print("Choose: ");
            int ch = sc.nextInt();

            switch (ch) {
                case 1:
                    ExpenseManager.addExpense();
                    break;
                case 2:
                    ExpenseManager.viewExpenses();
                    break;
                case 3:
                    ExpenseManager.monthlySummary();
                    break;
                case 4:
                    System.exit(0);
            }
        }
    }
}
