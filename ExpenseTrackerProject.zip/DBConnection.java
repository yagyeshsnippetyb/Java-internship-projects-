import java.sql.*;

public class DBConnection {
    static Connection conn;

    public static void connect() {
        try {
            conn = DriverManager.getConnection("jdbc:sqlite:expenses.db");
            Statement stmt = conn.createStatement();

            stmt.execute("CREATE TABLE IF NOT EXISTS expenses (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "category TEXT," +
                    "amount REAL," +
                    "date TEXT)");

            System.out.println("Database Connected");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
