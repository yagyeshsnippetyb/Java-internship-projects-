import java.sql.*;
import java.util.Scanner;

public class ExpenseManager {

    public static void addExpense() {
        try {
            Scanner sc = new Scanner(System.in);
            System.out.print("Category: ");
            String cat = sc.nextLine();
            System.out.print("Amount: ");
            double amt = sc.nextDouble();
            System.out.print("Date (YYYY-MM): ");
            String date = sc.next();

            PreparedStatement ps = DBConnection.conn.prepareStatement(
                    "INSERT INTO expenses(category, amount, date) VALUES (?, ?, ?)");
            ps.setString(1, cat);
            ps.setDouble(2, amt);
            ps.setString(3, date);
            ps.executeUpdate();

            System.out.println("Expense Added");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void viewExpenses() {
        try {
            Statement stmt = DBConnection.conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM expenses");

            while (rs.next()) {
                System.out.println(rs.getInt("id") + " | " +
                        rs.getString("category") + " | " +
                        rs.getDouble("amount") + " | " +
                        rs.getString("date"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void monthlySummary() {
        try {
            Statement stmt = DBConnection.conn.createStatement();
            ResultSet rs = stmt.executeQuery(
                    "SELECT date, SUM(amount) as total FROM expenses GROUP BY date");

            while (rs.next()) {
                System.out.println("Month: " + rs.getString("date") +
                        " Total: " + rs.getDouble("total"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
