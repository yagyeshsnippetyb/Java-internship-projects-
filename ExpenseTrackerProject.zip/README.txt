Expense Tracker Project (Java + SQLite)

How to Run:
1. Install Java (JDK 8+)
2. Download SQLite JDBC Driver
3. Compile:
   javac -cp ".;sqlite-jdbc.jar" *.java
4. Run:
   java -cp ".;sqlite-jdbc.jar" Main

Features:
- Add expenses
- View all expenses
- Monthly summary
