
public class Main {
    public static void main(String[] args) {
        try {
            int userId = Login.loginUser();
            if (userId != -1) {
                Quiz.startQuiz(userId);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
