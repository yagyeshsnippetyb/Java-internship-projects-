
import java.sql.*;
import java.util.Scanner;

public class Login {
    public static int loginUser() throws Exception {
        Scanner sc = new Scanner(System.in);
        System.out.print("Username: ");
        String user = sc.nextLine();
        System.out.print("Password: ");
        String pass = sc.nextLine();

        Connection con = DBConnection.getConnection();
        PreparedStatement ps = con.prepareStatement(
            "SELECT * FROM users WHERE username=? AND password=?"
        );
        ps.setString(1, user);
        ps.setString(2, pass);

        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            System.out.println("Login Successful!");
            return rs.getInt("id");
        } else {
            System.out.println("Invalid login");
            return -1;
        }
    }
}
