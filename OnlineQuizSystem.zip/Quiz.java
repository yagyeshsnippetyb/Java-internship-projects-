
import java.sql.*;
import java.util.*;

public class Quiz {
    public static void startQuiz(int userId) throws Exception {
        Connection con = DBConnection.getConnection();
        Statement st = con.createStatement();
        ResultSet rs = st.executeQuery("SELECT * FROM questions ORDER BY RAND() LIMIT 5");

        Scanner sc = new Scanner(System.in);
        int score = 0;

        while (rs.next()) {
            System.out.println(rs.getString("question"));
            System.out.println("A. " + rs.getString("optionA"));
            System.out.println("B. " + rs.getString("optionB"));
            System.out.println("C. " + rs.getString("optionC"));
            System.out.println("D. " + rs.getString("optionD"));

            String ans = sc.nextLine().toUpperCase();
            if (ans.equals(rs.getString("correct"))) {
                score++;
            }
        }

        PreparedStatement ps = con.prepareStatement(
            "INSERT INTO results(user_id, score) VALUES (?,?)"
        );
        ps.setInt(1, userId);
        ps.setInt(2, score);
        ps.executeUpdate();

        System.out.println("Your Score: " + score);
    }
}
