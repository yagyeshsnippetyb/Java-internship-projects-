import java.util.Timer;
import java.util.TimerTask;

public class ReminderService {

    public static void setReminder(Task task) {
        Timer timer = new Timer();

        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                System.out.println("Reminder: " + task.title);
            }
        }, 0, 10000);
    }
}
