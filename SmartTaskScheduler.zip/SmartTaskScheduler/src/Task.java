import java.io.Serializable;
import java.time.LocalDate;

public class Task implements Comparable<Task>, Serializable {
    String title;
    int priority;
    LocalDate deadline;

    public Task(String title, int priority, LocalDate deadline) {
        this.title = title;
        this.priority = priority;
        this.deadline = deadline;
    }

    @Override
    public int compareTo(Task other) {
        if (this.priority != other.priority) {
            return this.priority - other.priority;
        }
        return this.deadline.compareTo(other.deadline);
    }

    public String toString() {
        return title + " | Priority: " + priority + " | Deadline: " + deadline;
    }
}
