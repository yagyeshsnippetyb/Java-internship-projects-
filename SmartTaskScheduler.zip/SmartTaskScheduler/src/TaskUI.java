import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;

public class TaskUI {

    TaskManager manager = new TaskManager();
    DefaultListModel<String> listModel = new DefaultListModel<>();

    public TaskUI() {
        JFrame frame = new JFrame("Smart Task Scheduler");
        frame.setSize(500, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JTextField title = new JTextField();
        JTextField priority = new JTextField();
        JTextField deadline = new JTextField();

        JButton addBtn = new JButton("Add Task");
        JButton delBtn = new JButton("Delete Top Task");

        JList<String> list = new JList<>(listModel);

        frame.setLayout(new GridLayout(9,1));
        frame.add(new JLabel("Title"));
        frame.add(title);
        frame.add(new JLabel("Priority (1 = High)"));
        frame.add(priority);
        frame.add(new JLabel("Deadline (YYYY-MM-DD)"));
        frame.add(deadline);
        frame.add(addBtn);
        frame.add(delBtn);
        frame.add(new JScrollPane(list));

        addBtn.addActionListener(e -> {
            try {
                Task t = new Task(
                        title.getText(),
                        Integer.parseInt(priority.getText()),
                        LocalDate.parse(deadline.getText())
                );

                manager.addTask(t);
                updateList();

                title.setText("");
                priority.setText("");
                deadline.setText("");

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(frame, "Invalid Input!");
            }
        });

        delBtn.addActionListener(e -> {
            manager.removeTask();
            updateList();
        });

        frame.setVisible(true);
    }

    void updateList() {
        listModel.clear();
        for (Task t : manager.getTasks()) {
            listModel.addElement(t.toString());
        }
    }

    public static void main(String[] args) {
        new TaskUI();
    }
}
