import java.io.*;
import java.util.PriorityQueue;

public class FileHandler {

    public static void save(PriorityQueue<Task> tasks) {
        try {
            ObjectOutputStream out = new ObjectOutputStream(
                    new FileOutputStream("tasks.dat"));
            out.writeObject(tasks);
            out.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static PriorityQueue<Task> load() {
        try {
            ObjectInputStream in = new ObjectInputStream(
                    new FileInputStream("tasks.dat"));
            PriorityQueue<Task> tasks = (PriorityQueue<Task>) in.readObject();
            in.close();
            return tasks;
        } catch (Exception e) {
            return new PriorityQueue<>();
        }
    }
}
