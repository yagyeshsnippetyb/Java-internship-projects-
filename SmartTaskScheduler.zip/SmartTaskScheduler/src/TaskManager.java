import java.util.PriorityQueue;

public class TaskManager {
    PriorityQueue<Task> tasks = new PriorityQueue<>();

    public void addTask(Task t) {
        tasks.add(t);
    }

    public Task removeTask() {
        return tasks.poll();
    }

    public PriorityQueue<Task> getTasks() {
        return tasks;
    }
}
